
const gameApp = new Vue({
  el: '#main',
  data: {
    winMessage: '', // game over message, also used as game over flag
    moveCount: 0,
    turnSymbols: ['X', 'O'],  // just used to help us switch players without a conditional
    score: { X:0, O:0 },  // score as an object keyed by player symbol, for easy update
    board: [ null, null, null, null, null, null, null, null, null ], // board: new Array(9).fill(null)  //ES6
    winningCombo: [],  // for the fun colour animation (stores winning squares)
    winCombos: [
      [0,1,2], [3,4,5], [6,7,8], //rows
      [0,3,6], [1,4,7], [2,5,8], //cols
      [0,4,8], [2,4,6]           //diags
    ],
  },
  methods: {
    checkWin: function( board, symbol ){
      return this.winCombos.find(function( [a,b,c] ){
        // array destructuring in argument to get each number in combo
        return (symbol + symbol + symbol) === (board[a] + board[b] + board[c]);
      });
    },

    getCellWin: function( position ){
      
      return this.winningCombo.includes(position) ? 'celebrate' : '';
    },

    playMove: function( position ){

      if( this.board[position] || this.winMessage ){
        return; 
      }

      const turn = this.turnSymbols[ this.moveCount % 2 ]; 

      Vue.set(this.board, position, turn);  
      this.moveCount++;

      this.winningCombo = this.checkWin(this.board, turn) || [];
      if( this.winningCombo.length ){
        this.winMessage = `${turn} wins`;
        this.score[turn] += 1; 
      } else if( this.moveCount >= 9 ){
        this.winMessage = 'Draw';
      }

    }, // playMove()

   restartGame: function(){
     this.board = []; /
     this.winningCombo = [];
     this.moveCount = 0;
     this.winMessage = '';
   },

  }
});
